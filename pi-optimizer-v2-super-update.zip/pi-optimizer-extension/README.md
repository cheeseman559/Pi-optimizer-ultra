# ⚡ Pi Optimizer — Version 2.0.0 (Security & Speed)

**The most extreme Chrome optimizer and security shield, specifically engineered to make the Raspberry Pi 3 feel like a modern PC.**

---

## 🛡️ Strict Privacy & Security
This update introduces the **Malware & Phishing Shield** alongside our **Zero-Data Collection Policy**.
- **Security**: Automatically blocks known malicious domains and phishing sites.
- **Privacy**: No information is ever collected, stored, or transmitted. Everything stays local.

---

## 🚀 What's New in Version 2.0.0

This update combines the "Extreme Engineering" of previous builds with a new security layer:

| Feature | Engineering Logic | Impact |
|---|---|---|
| **🛡️ Malware Shield** | Integrated blocking for malicious and phishing domains. | Safer browsing and less CPU spent on junk. |
| **🧹 DOM Decimation** | Auto-deletes hidden/non-essential DOM nodes every 5s. | Frees massive RAM & CPU layout time. |
| **🕹️ Input Throttling** | Caps mouse/scroll event frequency to 5Hz. | Prevents CPU spikes during interaction. |
| **👻 Visual Ghosting** | Strips all CSS filters/shadows and pixelates images. | Drastically reduces GPU rendering load. |
| **🔡 Font Standardization** | Forces a single system font across all sites. | Skips expensive font loading & layout calcs. |
| **🚀 V8 Turbo Hints** | Injects low-level hints to prioritize JS execution speed. | Makes web apps feel significantly snappier. |

---

## 🎯 Recommended Settings for Raspberry Pi 3
*Developed for the Raspberry Pi 3 and up. Optimized for all devices.*

1. **Ad-Blocker**: Keep this ON (Default) to save bandwidth and CPU.
2. **Ghost Mode**: Use for heavy sites to strip them to essentials.
3. **V8 Turbo Mode**: Enable for a snappier feel on complex web apps.
4. **Performance Score**: Aim to keep your score above 80 for a smooth experience.

---

## 📦 Installation

### Method 1: Load Unpacked (Recommended for Pi)

1. Open Chrome/Chromium and navigate to `chrome://extensions`
2. Enable **Developer Mode** (toggle in top-right corner)
3. Click **"Load unpacked"**
4. Select the `pi-optimizer-extension` folder
5. The extension icon (⚡) will appear in your toolbar
6. Click it to open the dashboard

### Method 2: Pack as .crx

1. Go to `chrome://extensions`
2. Enable Developer Mode
3. Click **"Pack extension"**
4. Select the `pi-optimizer-extension` folder
5. Install the generated `.crx` file

---

## ⚙️ Optimization Modules

### 🧠 Memory Management
| Feature | Description | RAM Savings |
|---|---|---|
| Auto Tab Suspension | Discards inactive tabs from memory | ~80 MB per tab |
| Max Active Tabs | Enforces a hard limit on loaded tabs | Scales with tab count |
| Aggressive GC | Periodically nudges V8 garbage collector | 10–30 MB |
| Clear Cache on Idle | Wipes browser cache when you stop browsing | Varies |

### 🌐 Network Optimizations
| Feature | Description |
|---|---|
| Block Ads & Trackers | Blocks 30+ ad networks and analytics scripts |
| Block Images | Removes all images for text-only browsing |
| Block Web Fonts | Uses system fonts instead of downloading custom ones |
| Block Media | Prevents video/audio files from loading |
| Block Third-Party Scripts | Stops scripts from external domains |
| Block Autoplay | Prevents videos from auto-playing |

### 🎨 Rendering Optimizations
| Feature | Description | CPU Savings |
|---|---|---|
| Kill All Animations | Disables all CSS animations & transitions | 15–40% |
| Reduced Motion Mode | Enforces prefers-reduced-motion globally | 10–20% |
| Limit Frame Rate | Caps requestAnimationFrame (default: 30 FPS) | 20–50% |
| Optimize Scrollbars | Thin native scrollbars reduce GPU paint area | 5–10% |
| Simplify Pages | Removes shadows, gradients, filters | 10–25% |
| Throttle Background Tabs | Slows timers in hidden tabs | 15–30% |
| Defer Offscreen Content | Pauses off-screen videos, defers rendering | 10–20% |

### 📋 Tab Manager
- View all open tabs with status indicators
- Manually suspend or resume individual tabs
- Close tabs directly from the dashboard
- Real-time active/suspended/audible badges

---

## 🎯 Recommended Settings for Raspberry Pi 3

For the absolute best performance on a Pi 3:

**Memory Tab:**
- ✅ Auto Tab Suspension: ON
- ⏱️ Suspend After: 1 minute
- 📊 Max Active Tabs: 3–5
- ✅ Aggressive GC: ON, every 30 seconds
- ✅ Clear Cache on Idle: ON, 2 minutes

**Network Tab:**
- ✅ Block Ads & Trackers: ON
- ✅ Block Autoplay: ON
- ⚠️ Block Images: ON (for text-heavy browsing)

**Rendering Tab:**
- ✅ Kill All Animations: ON
- ✅ Reduced Motion: ON
- ✅ Limit Frame Rate: ON → 24–30 FPS
- ✅ Optimize Scrollbars: ON
- ✅ Throttle Background Tabs: ON
- ✅ Defer Offscreen Content: ON

---

## 📊 Dashboard Features

- **Live Stats Bar**: Active tabs, suspended tabs, RAM saved, requests blocked
- **System Monitor**: Available RAM, CPU cores, session time, total tabs
- **Quick Actions**: One-click suspend all, free RAM, clear cache, deep clean
- **Tab Manager**: Full tab list with per-tab controls
- **Advanced Panel**: Granular data clearing, detailed stats, optimization tips

---

## 🔧 Technical Details

- **Manifest Version**: 3 (latest standard)
- **Background**: Service Worker (minimal memory footprint)
- **Content Script**: Injected at `document_start` for maximum effect
- **Network Rules**: Declarative Net Request (most efficient blocking API)
- **Permissions**: tabs, storage, alarms, scripting, browsingData, system.memory, system.cpu, webRequest, declarativeNetRequest

---

## 💡 Tips

- The **biggest single win** is enabling tab suspension + killing animations together
- Use **"Suspend All Inactive"** when you notice Chrome getting slow
- **"Deep Clean"** weekly removes accumulated cache and service worker data
- If a website breaks, try disabling "Block Third-Party Scripts" or "Simplify Pages"
- The **30 FPS cap** is nearly imperceptible for web browsing but saves significant CPU

---

*Pi Optimizer v1.0 — Built for Raspberry Pi 3 and ultra-low-end devices*
