// ============================================================
// Pi Optimizer — Popup Script
// Dashboard logic, settings sync, tab manager
// ============================================================

'use strict';

// ─── State ───────────────────────────────────────────────────
let currentSettings = null;
let statsRefreshInterval = null;

// ─── DOM Ready ───────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadAndRenderSettings();
  await refreshStats();
  setupTabNavigation();
  setupEventListeners();
  await loadTabList();

  // Auto-refresh stats every 5 seconds
  statsRefreshInterval = setInterval(async () => {
    await refreshStats();
  }, 5000);
});

// ─── Settings ────────────────────────────────────────────────
async function loadAndRenderSettings() {
  try {
    const response = await sendMessage({ action: 'getSettings' });
    if (response && response.settings) {
      currentSettings = response.settings;
      renderSettings(currentSettings);
      updateMasterState(currentSettings.masterEnabled);
    }
  } catch (e) {
    showToast('Could not load settings', 'error');
  }
}

function renderSettings(s) {
  const fields = [
    'masterEnabled', 'domDecimation', 'inputThrottling', 'visualGhosting', 'fontStandardization',
    'jsMemoryCapping', 'zIndexFlattening', 'workerThrottling', 'fingerprintShield',
    'ghostMode', 'extremeScriptFreezing', 'siteSpecificOptimizations',
    'lowLevelMemoryPurge', 'v8TurboMode', 'cpuPinningMode', 'canvasThrottling',
    'autoSuspendEnabled', 'suspendDelay', 'suspendPinnedTabs',
    'suspendAudibleTabs', 'maxActiveTabs', 'aggressiveGC', 'gcInterval',
    'clearCacheOnIdle', 'idleThreshold', 'blockAdsTrackers', 'blockImages',
    'blockFonts', 'blockMedia', 'blockThirdPartyScripts', 'disableAutoplay',
    'disableAnimations', 'reducedMotion', 'limitFrameRate', 'targetFPS',
    'disableCustomScrollbars', 'simplifyPages', 'throttleBackgroundTabs',
    'deferOffscreenContent', 'disableWebGL', 'disableWebRTC'
  ];

  fields.forEach(field => {
    let el = document.getElementById(field);
    if (!el && field === 'ghostMode') {
      // Special case for ghostMode which has two toggles
      const inner = document.getElementById('ghostMode_inner');
      const outer = document.getElementById('ghostMode');
      if (inner) inner.checked = !!s[field];
      if (outer) outer.checked = !!s[field];
      return;
    }
    if (!el) return;
    if (el.type === 'checkbox') {
      el.checked = !!s[field];
    } else if (el.tagName === 'SELECT') {
      el.value = String(s[field]);
    }
  });
}

function collectSettings() {
  const s = { ...currentSettings };
  const checkboxFields = [
    'masterEnabled', 'domDecimation', 'inputThrottling', 'visualGhosting', 'fontStandardization',
    'jsMemoryCapping', 'zIndexFlattening', 'workerThrottling', 'fingerprintShield',
    'ghostMode', 'extremeScriptFreezing', 'siteSpecificOptimizations',
    'lowLevelMemoryPurge', 'v8TurboMode', 'cpuPinningMode', 'canvasThrottling',
    'autoSuspendEnabled', 'suspendPinnedTabs', 'suspendAudibleTabs',
    'aggressiveGC', 'clearCacheOnIdle', 'blockAdsTrackers', 'blockImages', 'blockFonts',
    'blockMedia', 'blockThirdPartyScripts', 'disableAutoplay', 'disableAnimations',
    'reducedMotion', 'limitFrameRate', 'disableCustomScrollbars', 'simplifyPages',
    'throttleBackgroundTabs', 'deferOffscreenContent', 'disableWebGL', 'disableWebRTC'
  ];
  const numberFields = [
    'suspendDelay', 'maxActiveTabs', 'gcInterval', 'idleThreshold', 'targetFPS'
  ];

  checkboxFields.forEach(f => {
    let el = document.getElementById(f);
    if (!el && f === 'ghostMode') {
      el = document.getElementById('ghostMode_inner') || document.getElementById('ghostMode');
    }
    if (el) s[f] = el.checked;
  });

  numberFields.forEach(f => {
    const el = document.getElementById(f);
    if (el) s[f] = parseInt(el.value, 10);
  });

  return s;
}

async function saveSettings(newSettings) {
  try {
    const response = await sendMessage({ action: 'updateSettings', settings: newSettings });
    if (response && response.settings) {
      currentSettings = response.settings;
    }
  } catch (e) {
    showToast('Failed to save settings', 'error');
  }
}

function updateMasterState(enabled) {
  const label = document.querySelector('.master-label');
  const footer = document.getElementById('footer-status');
  if (label) label.textContent = enabled ? 'ACTIVE' : 'OFF';
  if (footer) {
    footer.textContent = enabled ? '●  Running' : '●  Disabled';
    footer.className = enabled ? 'footer-status' : 'footer-status inactive';
  }
  if (enabled) {
    document.body.classList.remove('optimizer-disabled');
  } else {
    document.body.classList.add('optimizer-disabled');
  }
}

// ─── Stats ───────────────────────────────────────────────────
async function refreshStats() {
  try {
    const stats = await sendMessage({ action: 'getStats' });
    if (!stats) return;

    // Stats bar
    setEl('stat-active', stats.activeTabs ?? '—');
    setEl('stat-suspended', stats.suspendedTabs ?? '—');
    
    const scoreEl = document.getElementById('stat-score');
    if (scoreEl) {
      scoreEl.textContent = stats.performanceScore || '--';
      if (stats.performanceScore > 80) scoreEl.style.color = 'var(--green)';
      else if (stats.performanceScore > 50) scoreEl.style.color = 'var(--yellow)';
      else scoreEl.style.color = 'var(--red)';
    }

    setEl('stat-blocked', formatCount(stats.requestsBlocked));

    // System monitor
    if (stats.memInfo) {
      const total = stats.memInfo.capacity / (1024 * 1024);
      const avail = stats.memInfo.availableCapacity / (1024 * 1024);
      const used = total - avail;
      const pct = Math.round((used / total) * 100);
      setEl('ram-value', `${Math.round(avail)} MB free / ${Math.round(total)} MB`);
      const bar = document.getElementById('ram-bar');
      if (bar) bar.style.width = `${pct}%`;
    } else {
      setEl('ram-value', 'N/A');
    }

    if (stats.cpuInfo) {
      const cores = stats.cpuInfo.numOfProcessors || stats.cpuInfo.processors?.length || '?';
      const model = (stats.cpuInfo.modelName || stats.cpuInfo.archName || 'Unknown CPU').substring(0, 30);
      setEl('cpu-value', `${cores} core${cores !== 1 ? 's' : ''}`);
    } else {
      setEl('cpu-value', 'N/A');
    }

    setEl('session-time', formatDuration(stats.sessionDuration));
    setEl('total-tabs', stats.totalTabs ?? '—');

    // Advanced stats
    setEl('adv-tabs-suspended', stats.tabsSuspendedTotal ?? '—');
    setEl('adv-ram-saved', formatMB(stats.memorySavedMB));
    setEl('adv-blocked', formatCount(stats.requestsBlocked));
    setEl('adv-session', formatDuration(stats.sessionDuration));

  } catch (e) {
    // Silently fail on stats refresh
  }
}

// ─── Tab Navigation ──────────────────────────────────────────
function setupTabNavigation() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.dataset.tab;
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      const target = document.getElementById(targetId);
      if (target) target.classList.add('active');

      // Load tab list when switching to tab manager
      if (targetId === 'tab-tabs') {
        loadTabList();
      }
    });
  });
}

// ─── Event Listeners ─────────────────────────────────────────
function setupEventListeners() {
  // All toggles and selects — auto-save on change
  const allInputs = document.querySelectorAll('input[type="checkbox"], select');
  allInputs.forEach(input => {
    input.addEventListener('change', async () => {
      const newSettings = collectSettings();
      currentSettings = newSettings;
      await saveSettings(newSettings);

      // Update master state immediately
      if (input.id === 'masterEnabled') {
        updateMasterState(input.checked);
      }

      showToast('Settings saved', 'success');
    });
  });

  // Quick action buttons
  document.getElementById('btn-suspend-all')?.addEventListener('click', async () => {
    showToast('Suspending inactive tabs...', 'info');
    await sendMessage({ action: 'suspendAllInactive' });
    await refreshStats();
    await loadTabList();
    showToast('Inactive tabs suspended!', 'success');
  });

  document.getElementById('btn-force-gc')?.addEventListener('click', async () => {
    showToast('Freeing RAM...', 'info');
    await sendMessage({ action: 'forceGC' });
    await refreshStats();
    showToast('Memory cleanup triggered!', 'success');
  });

  document.getElementById('btn-clear-cache')?.addEventListener('click', async () => {
    showToast('Clearing cache...', 'info');
    await sendMessage({ action: 'clearBrowsingData', options: { cache: true } });
    showToast('Cache cleared!', 'success');
  });

  document.getElementById('btn-nuke-data')?.addEventListener('click', async () => {
    showToast('Deep cleaning...', 'info');
    await sendMessage({
      action: 'clearBrowsingData',
      options: {
        cache: true,
        cacheStorage: true,
        serviceWorkers: true,
        indexedDB: true
      }
    });
    showToast('Deep clean complete!', 'success');
  });

  document.getElementById('refresh-stats')?.addEventListener('click', async () => {
    await refreshStats();
    showToast('Stats refreshed', 'info');
  });

  document.getElementById('btn-refresh-tabs')?.addEventListener('click', async () => {
    await loadTabList();
  });

  document.getElementById('btn-reset-stats')?.addEventListener('click', async () => {
    await sendMessage({ action: 'resetStats' });
    await refreshStats();
    showToast('Stats reset!', 'success');
  });

  // Advanced clear buttons
  document.getElementById('clear-cache-only')?.addEventListener('click', async () => {
    await sendMessage({ action: 'clearBrowsingData', options: { cache: true } });
    showToast('Cache cleared!', 'success');
  });

  document.getElementById('clear-cookies')?.addEventListener('click', async () => {
    await sendMessage({ action: 'clearBrowsingData', options: { cookies: true } });
    showToast('Cookies cleared!', 'success');
  });

  document.getElementById('clear-history')?.addEventListener('click', async () => {
    await sendMessage({ action: 'clearBrowsingData', options: { history: true } });
    showToast('History cleared!', 'success');
  });

  document.getElementById('clear-storage')?.addEventListener('click', async () => {
    await sendMessage({ action: 'clearBrowsingData', options: { localStorage: true } });
    showToast('Local storage cleared!', 'success');
  });

  document.getElementById('clear-indexeddb')?.addEventListener('click', async () => {
    await sendMessage({ action: 'clearBrowsingData', options: { indexedDB: true } });
    showToast('IndexedDB cleared!', 'success');
  });

  document.getElementById('clear-service-workers')?.addEventListener('click', async () => {
    await sendMessage({ action: 'clearBrowsingData', options: { serviceWorkers: true } });
    showToast('Service workers cleared!', 'success');
  });
}

// ─── Tab Manager ─────────────────────────────────────────────
async function loadTabList() {
  const listEl = document.getElementById('tab-list');
  const countEl = document.getElementById('tab-manager-count');
  if (!listEl) return;

  listEl.innerHTML = '<div class="loading-msg">Loading tabs...</div>';

  try {
    const tabs = await sendMessage({ action: 'getTabList' });
    if (!tabs || !Array.isArray(tabs)) {
      listEl.innerHTML = '<div class="loading-msg">Could not load tabs</div>';
      return;
    }

    const active = tabs.filter(t => !t.discarded).length;
    const suspended = tabs.filter(t => t.discarded).length;
    if (countEl) countEl.textContent = `${tabs.length} tabs — ${active} active, ${suspended} suspended`;

    if (tabs.length === 0) {
      listEl.innerHTML = '<div class="loading-msg">No tabs found</div>';
      return;
    }

    // Sort: active first, then by last active time
    tabs.sort((a, b) => {
      if (a.active && !b.active) return -1;
      if (!a.active && b.active) return 1;
      return (b.lastActive || 0) - (a.lastActive || 0);
    });

    listEl.innerHTML = '';
    tabs.forEach(tab => {
      const item = buildTabItem(tab);
      listEl.appendChild(item);
    });

  } catch (e) {
    listEl.innerHTML = '<div class="loading-msg">Error loading tabs</div>';
  }
}

function buildTabItem(tab) {
  const div = document.createElement('div');
  div.className = `tab-item${tab.active ? ' is-active' : ''}${tab.discarded ? ' is-suspended' : ''}${tab.audible ? ' is-audible' : ''}`;
  div.dataset.tabId = tab.id;

  // Favicon
  let faviconHtml;
  if (tab.favIconUrl && tab.favIconUrl.startsWith('http')) {
    faviconHtml = `<img class="tab-favicon" src="${escHtml(tab.favIconUrl)}" onerror="this.style.display='none'" alt="">`;
  } else {
    faviconHtml = `<div class="tab-favicon-placeholder">🌐</div>`;
  }

  // Badges
  const badges = [];
  if (tab.active) badges.push('<span class="badge active">Active</span>');
  if (tab.discarded) badges.push('<span class="badge suspended">Suspended</span>');
  if (tab.audible) badges.push('<span class="badge audible">♪</span>');
  if (tab.pinned) badges.push('<span class="badge pinned">📌</span>');

  // Actions
  let actionsHtml = '';
  if (tab.discarded) {
    actionsHtml = `<button class="tab-action-btn resume" data-action="resume" data-id="${tab.id}">Resume</button>`;
  } else if (!tab.active) {
    actionsHtml = `<button class="tab-action-btn suspend" data-action="suspend" data-id="${tab.id}">Suspend</button>`;
  }
  actionsHtml += `<button class="tab-action-btn close" data-action="close" data-id="${tab.id}">✕</button>`;

  // URL display
  let displayUrl = '';
  try {
    const url = new URL(tab.url || '');
    displayUrl = url.hostname;
  } catch (e) {
    displayUrl = tab.url ? tab.url.substring(0, 40) : '';
  }

  div.innerHTML = `
    ${faviconHtml}
    <div class="tab-info">
      <div class="tab-title">${escHtml(tab.title || 'Untitled')}</div>
      <div class="tab-url">${escHtml(displayUrl)}</div>
    </div>
    <div class="tab-badges">${badges.join('')}</div>
    <div class="tab-actions">${actionsHtml}</div>
  `;

  // Action handlers
  div.querySelectorAll('[data-action]').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const action = btn.dataset.action;
      const id = parseInt(btn.dataset.id, 10);

      if (action === 'suspend') {
        await sendMessage({ action: 'suspendTab', tabId: id });
        showToast('Tab suspended', 'success');
      } else if (action === 'resume') {
        await sendMessage({ action: 'unsuspendTab', tabId: id });
        showToast('Tab resumed', 'info');
      } else if (action === 'close') {
        await sendMessage({ action: 'closeTab', tabId: id });
        showToast('Tab closed', 'info');
      }

      await loadTabList();
      await refreshStats();
    });
  });

  return div;
}

// ─── Utilities ───────────────────────────────────────────────
function sendMessage(msg) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(msg, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response);
        }
      });
    } catch (e) {
      reject(e);
    }
  });
}

function setEl(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatMB(mb) {
  if (!mb || mb === 0) return '0 MB';
  if (mb >= 1024) return `${(mb / 1024).toFixed(1)} GB`;
  return `${Math.round(mb)} MB`;
}

function formatCount(n) {
  if (!n || n === 0) return '0';
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return String(n);
}

function formatDuration(seconds) {
  if (!seconds) return '0s';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

let toastTimeout = null;
function showToast(msg, type = 'success') {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.className = `toast show ${type}`;
  if (toastTimeout) clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.className = 'toast';
  }, 2000);
}
