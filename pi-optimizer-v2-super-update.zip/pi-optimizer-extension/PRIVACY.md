# 🔒 Pi Optimizer Privacy Statement

**Version 5.0 — "Privacy & Power" Release**

At Pi Optimizer, we believe that performance should never come at the cost of privacy. This extension is designed to be a local-only tool with a strict zero-data-collection policy.

### 🛡️ Our Commitment
- **Zero Data Collection**: We do not collect, store, or transmit any of your browsing history, personal information, or usage statistics to any external servers.
- **Local Processing**: All optimization logic, tab management, and performance analysis happen entirely within your local browser environment.
- **No Third-Party Analytics**: We do not use any third-party tracking or analytics scripts within the extension.
- **No Cloud Sync**: Your settings are stored locally on your device using the `chrome.storage.local` API and never leave your machine.

### 🛠️ Permissions Usage
- **Tabs**: Used solely to manage and suspend inactive tabs to save RAM.
- **Storage**: Used to save your optimization preferences locally.
- **System (CPU/Memory)**: Used to provide you with real-time performance data so you can optimize your device.
- **Declarative Net Request**: Used to block ads and trackers locally to speed up page loads.

*Developed for the Raspberry Pi 3 and up. Optimized for all devices.*
