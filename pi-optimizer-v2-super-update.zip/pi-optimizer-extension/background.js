// ============================================================
// Pi Optimizer — Background Service Worker
// Extreme Chrome optimization for Raspberry Pi 3 & low-end devices
// ============================================================

// ─── Default Settings ────────────────────────────────────────
const DEFAULT_SETTINGS = {
  // Version 10.0 - Extreme Engineering Update
  masterEnabled: true,
  privacyStatementAccepted: true,

  // v10.0 Extreme Features
  domDecimation: false,
  inputThrottling: false,
  visualGhosting: false,
  fontStandardization: false,
  jsMemoryCapping: false,
  zIndexFlattening: false,
  workerThrottling: false,
  fingerprintShield: false,

  // v5.0 Features
  ghostMode: false,
  extremeScriptFreezing: false,
  siteSpecificOptimizations: false,
  lowLevelMemoryPurge: false,

  // Tab Management
  autoSuspendEnabled: false,
  suspendDelay: 300,
  suspendPinnedTabs: false,
  suspendAudibleTabs: false,
  maxActiveTabs: 10,

  // Network Optimizations
  blockAdsTrackers: true,      // ON BY DEFAULT
  blockImages: false,
  blockFonts: false,
  blockMedia: false,
  blockThirdPartyScripts: false,
  dnsPrefetching: false,

  // Rendering Optimizations
  disableAnimations: true,     // ON BY DEFAULT
  reducedMotion: true,         // ON BY DEFAULT
  disableCustomScrollbars: false,
  forceLightMode: false,
  simplifyPages: false,
  limitFrameRate: false,
  targetFPS: 60,
  gpuRasterization: false,
  canvasThrottling: false,

  // Memory Management
  aggressiveGC: false,
  gcInterval: 60,
  clearCacheOnIdle: false,
  idleThreshold: 300,
  aggressiveMemoryPurge: false,

  // CPU Throttling
  throttleBackgroundTabs: false,
  deferOffscreenContent: false,
  cpuPinningMode: false,

  // JavaScript Optimizations
  disableWebGL: false,
  disableWebRTC: false,
  disableAutoplay: false,
  v8TurboMode: false,

  // Stats
  tabsSuspended: 0,
  memorySaved: 0,
  requestsBlocked: 0,
  sessionStartTime: Date.now()
};

// ─── State ───────────────────────────────────────────────────
let settings = { ...DEFAULT_SETTINGS };
let tabLastActive = {};       // tabId -> timestamp
let suspendTimers = {};       // tabId -> alarmName
let requestsBlocked = 0;
let sessionStartTime = Date.now();

// ─── Initialization ──────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    await chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
    console.log('[Pi Optimizer] Installed — applying default optimizations');
  } else if (details.reason === 'update') {
    const stored = await chrome.storage.local.get('settings');
    settings = { ...DEFAULT_SETTINGS, ...(stored.settings || {}) };
    await chrome.storage.local.set({ settings });
  }
  await loadSettings();
  applyNetworkRules();
  setupAlarms();
  initTabTracking();
});

chrome.runtime.onStartup.addListener(async () => {
  await loadSettings();
  applyNetworkRules();
  setupAlarms();
  initTabTracking();
  sessionStartTime = Date.now();
  await chrome.storage.local.set({ sessionStartTime });
});

// ─── Settings Management ─────────────────────────────────────
async function loadSettings() {
  const stored = await chrome.storage.local.get('settings');
  if (stored.settings) {
    settings = { ...DEFAULT_SETTINGS, ...stored.settings };
  }
}

async function saveSettings() {
  await chrome.storage.local.set({ settings });
}

// ─── Message Handler ─────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender, sendResponse);
  return true; // keep channel open for async
});

async function handleMessage(message, sender, sendResponse) {
  switch (message.action) {
    case 'getSettings':
      await loadSettings();
      sendResponse({ settings });
      break;

    case 'updateSettings':
      settings = { ...settings, ...message.settings };
      await saveSettings();
      applyNetworkRules();
      setupAlarms();
      broadcastSettingsToAllTabs();
      sendResponse({ success: true, settings });
      break;

    case 'getStats':
      sendResponse(await buildStats());
      break;

    case 'forceGC':
      await forceGarbageCollection();
      sendResponse({ success: true });
      break;

    case 'suspendAllInactive':
      await suspendAllInactiveTabs();
      sendResponse({ success: true });
      break;

    case 'clearBrowsingData':
      await clearBrowsingData(message.options);
      sendResponse({ success: true });
      break;

    case 'resetStats':
      requestsBlocked = 0;
      sessionStartTime = Date.now();
      settings.tabsSuspended = 0;
      settings.memorySaved = 0;
      settings.requestsBlocked = 0;
      await saveSettings();
      sendResponse({ success: true });
      break;

    case 'getTabList':
      sendResponse(await getTabList());
      break;

    case 'suspendTab':
      await suspendTab(message.tabId);
      sendResponse({ success: true });
      break;

    case 'unsuspendTab':
      await unsuspendTab(message.tabId);
      sendResponse({ success: true });
      break;

    case 'closeTab':
      chrome.tabs.remove(message.tabId);
      sendResponse({ success: true });
      break;

    default:
      sendResponse({ error: 'Unknown action' });
  }
}

// ─── Network Rules ───────────────────────────────────────────
async function applyNetworkRules() {
  try {
    if (settings.blockAdsTrackers) {
      await chrome.declarativeNetRequest.updateEnabledRulesets({
        enableRulesetIds: ['block_rules']
      });
    } else {
      await chrome.declarativeNetRequest.updateEnabledRulesets({
        disableRulesetIds: ['block_rules']
      });
    }
  } catch (e) {
    console.warn('[Pi Optimizer] Network rules error:', e.message);
  }
}

// ─── Tab Tracking ────────────────────────────────────────────
function initTabTracking() {
  chrome.tabs.onActivated.addListener(({ tabId }) => {
    tabLastActive[tabId] = Date.now();
    cancelSuspendTimer(tabId);
    // Unsuspend if it was discarded
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) return;
      if (tab && tab.discarded) {
        // Tab will reload automatically on activation
      }
    });
    // Enforce max active tabs
    if (settings.masterEnabled && settings.maxActiveTabs > 0) {
      enforceMaxActiveTabs();
    }
  });

  chrome.tabs.onCreated.addListener((tab) => {
    tabLastActive[tab.id] = Date.now();
    if (settings.masterEnabled && settings.maxActiveTabs > 0) {
      enforceMaxActiveTabs();
    }
  });

  chrome.tabs.onRemoved.addListener((tabId) => {
    delete tabLastActive[tabId];
    cancelSuspendTimer(tabId);
  });

  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') {
      if (tab.active) {
        tabLastActive[tabId] = Date.now();
      }
    }
  });

  // Initialize timestamps for existing tabs
  chrome.tabs.query({}, (tabs) => {
    const now = Date.now();
    tabs.forEach((tab) => {
      if (!tabLastActive[tab.id]) {
        tabLastActive[tab.id] = tab.active ? now : now - (settings.suspendDelay * 1000 * 0.5);
      }
    });
  });
}

// ─── Tab Suspension ──────────────────────────────────────────
function setupAlarms() {
  chrome.alarms.clearAll(() => {
    if (!settings.masterEnabled) return;

    // Auto-suspend scanner
    if (settings.autoSuspendEnabled) {
      chrome.alarms.create('scanTabs', { periodInMinutes: 0.5 }); // every 30s
    }

    // GC nudge
    if (settings.aggressiveGC) {
      const gcMins = Math.max(0.5, settings.gcInterval / 60);
      chrome.alarms.create('gcNudge', { periodInMinutes: gcMins });
    }

    // Idle cache clear
    if (settings.clearCacheOnIdle) {
      chrome.alarms.create('idleCheck', { periodInMinutes: 1 });
    }

    // Stats save
    chrome.alarms.create('saveStats', { periodInMinutes: 2 });
  });
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  switch (alarm.name) {
    case 'scanTabs':
      if (settings.masterEnabled && settings.autoSuspendEnabled) {
        await scanAndSuspendTabs();
      }
      break;
    case 'gcNudge':
      if (settings.masterEnabled && settings.aggressiveGC) {
        await forceGarbageCollection();
      }
      break;
    case 'idleCheck':
      if (settings.masterEnabled && settings.clearCacheOnIdle) {
        await checkIdleAndClear();
      }
      break;
    case 'saveStats':
      await persistStats();
      break;
  }
});

async function scanAndSuspendTabs() {
  const now = Date.now();
  const delayMs = settings.suspendDelay * 1000;

  chrome.tabs.query({}, (tabs) => {
    if (chrome.runtime.lastError) return;
    tabs.forEach((tab) => {
      if (!tab || tab.active || tab.discarded) return;
      if (!settings.suspendPinnedTabs && tab.pinned) return;
      if (!settings.suspendAudibleTabs && tab.audible) return;
      if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://'))) return;

      const lastActive = tabLastActive[tab.id] || 0;
      const idle = now - lastActive;

      if (idle >= delayMs) {
        suspendTab(tab.id);
      }
    });
  });
}

async function suspendTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab || tab.active || tab.discarded) return;
    if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://'))) return;

    await chrome.tabs.discard(tabId);
    settings.tabsSuspended = (settings.tabsSuspended || 0) + 1;
    settings.memorySaved = (settings.memorySaved || 0) + 80; // ~80MB avg per tab
    await saveSettings();
    console.log(`[Pi Optimizer] Suspended tab ${tabId}: ${tab.title}`);
  } catch (e) {
    // Tab may have been closed
  }
}

async function unsuspendTab(tabId) {
  try {
    await chrome.tabs.reload(tabId);
  } catch (e) {
    console.warn('[Pi Optimizer] Could not unsuspend tab:', e.message);
  }
}

async function suspendAllInactiveTabs() {
  const tabs = await chrome.tabs.query({ active: false, discarded: false });
  for (const tab of tabs) {
    if (!tab.pinned || settings.suspendPinnedTabs) {
      if (!tab.audible || settings.suspendAudibleTabs) {
        if (tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://')) {
          await suspendTab(tab.id);
          await sleep(50); // stagger to avoid overwhelming the Pi
        }
      }
    }
  }
}

function cancelSuspendTimer(tabId) {
  if (suspendTimers[tabId]) {
    chrome.alarms.clear(suspendTimers[tabId]);
    delete suspendTimers[tabId];
  }
}

async function enforceMaxActiveTabs() {
  if (settings.maxActiveTabs <= 0) return;
  const tabs = await chrome.tabs.query({ discarded: false });
  const nonPinned = tabs.filter(t => !t.pinned && !t.active &&
    t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://'));

  if (nonPinned.length > settings.maxActiveTabs) {
    // Sort by last active time, oldest first
    nonPinned.sort((a, b) => (tabLastActive[a.id] || 0) - (tabLastActive[b.id] || 0));
    const toSuspend = nonPinned.slice(0, nonPinned.length - settings.maxActiveTabs);
    for (const tab of toSuspend) {
      await suspendTab(tab.id);
      await sleep(30);
    }
  }
}

// ─── Memory & GC ─────────────────────────────────────────────
async function forceGarbageCollection() {
  // Ultra Edition: Low-level memory purge
  try {
    // 1. Browser-level cache purge
    await chrome.browsingData.removeCache({ since: 0 });
    
    // 2. Discard all non-active tabs immediately if lowLevelMemoryPurge is on
    if (settings.lowLevelMemoryPurge) {
      const tabs = await chrome.tabs.query({ active: false, discarded: false });
      for (const tab of tabs) {
        await chrome.tabs.discard(tab.id);
      }
    }
    
    // 3. V8 Nudge
    const arrays = [];
    for (let i = 0; i < 10; i++) {
      arrays.push(new Float64Array(1024 * 512)); // 4MB each, total 40MB nudge
    }
    arrays.length = 0;
    
    console.log('[Pi Optimizer Ultra] Aggressive Memory Purge Complete');
  } catch (e) {
    console.warn('[Pi Optimizer Ultra] Purge error:', e.message);
  }
}

let lastIdleTime = Date.now();
let lastUserActivity = Date.now();

chrome.tabs.onActivated.addListener(() => { lastUserActivity = Date.now(); });

async function checkIdleAndClear() {
  const idleMs = settings.idleThreshold * 1000;
  if (Date.now() - lastUserActivity > idleMs) {
    await clearBrowsingData({ cache: true });
    lastIdleTime = Date.now();
  }
}

async function clearBrowsingData(options = {}) {
  const dataToRemove = {};
  if (options.cache !== false) dataToRemove.cache = true;
  if (options.cacheStorage) dataToRemove.cacheStorage = true;
  if (options.cookies) dataToRemove.cookies = true;
  if (options.history) dataToRemove.history = true;
  if (options.downloads) dataToRemove.downloads = true;
  if (options.formData) dataToRemove.formData = true;
  if (options.localStorage) dataToRemove.localStorage = true;
  if (options.indexedDB) dataToRemove.indexedDB = true;
  if (options.serviceWorkers) dataToRemove.serviceWorkers = true;

  if (Object.keys(dataToRemove).length === 0) {
    dataToRemove.cache = true;
  }

  try {
    await chrome.browsingData.remove(
      { since: 0 },
      dataToRemove
    );
    console.log('[Pi Optimizer] Browsing data cleared:', Object.keys(dataToRemove).join(', '));
  } catch (e) {
    console.warn('[Pi Optimizer] Could not clear browsing data:', e.message);
  }
}

// ─── Stats ───────────────────────────────────────────────────
async function buildStats() {
  const tabs = await chrome.tabs.query({});
  const discarded = tabs.filter(t => t.discarded).length;
  const active = tabs.filter(t => !t.discarded).length;

  let memInfo = null;
  try {
    memInfo = await chrome.system.memory.getInfo();
  } catch (e) {}

  let cpuInfo = null;
  try {
    cpuInfo = await chrome.system.cpu.getInfo();
  } catch (e) {}

  const stored = await chrome.storage.local.get(['settings', 'sessionStartTime']);
  const s = stored.settings || settings;

  // v5.0 Advanced Analysis
  const performanceScore = calculatePerformanceScore(memInfo, cpuInfo, tabs);

  return {
    totalTabs: tabs.length,
    activeTabs: active,
    suspendedTabs: discarded,
    tabsSuspendedTotal: s.tabsSuspended || 0,
    memorySavedMB: s.memorySaved || 0,
    requestsBlocked: s.requestsBlocked || 0,
    sessionDuration: Math.floor((Date.now() - (stored.sessionStartTime || sessionStartTime)) / 1000),
    memInfo,
    cpuInfo,
    performanceScore,
    settings: s
  };
}

function calculatePerformanceScore(mem, cpu, tabs) {
  if (!mem || !cpu) return 50;
  const memFree = mem.availableCapacity / mem.capacity;
  const cpuLoad = cpu.processors.reduce((acc, p) => {
    const total = p.usage.user + p.usage.kernel + p.usage.idle;
    return acc + (1 - (p.usage.idle / total));
  }, 0) / cpu.numOfProcessors;
  
  const memScore = memFree * 50;
  const cpuScore = (1 - cpuLoad) * 30;
  const tabScore = Math.max(0, 20 - (tabs.length * 1));
  return Math.round(memScore + cpuScore + tabScore);
}

async function persistStats() {
  settings.requestsBlocked = requestsBlocked;
  await saveSettings();
}

// ─── Tab List ────────────────────────────────────────────────
async function getTabList() {
  const tabs = await chrome.tabs.query({});
  return tabs.map(tab => ({
    id: tab.id,
    title: tab.title || 'Untitled',
    url: tab.url || '',
    favIconUrl: tab.favIconUrl || '',
    active: tab.active,
    pinned: tab.pinned,
    audible: tab.audible,
    discarded: tab.discarded,
    frozen: tab.frozen || false,
    lastActive: tabLastActive[tab.id] || 0
  }));
}

// ─── Broadcast Settings to Content Scripts ───────────────────
async function broadcastSettingsToAllTabs() {
  const tabs = await chrome.tabs.query({ discarded: false });
  for (const tab of tabs) {
    if (tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://')) {
      try {
        await chrome.tabs.sendMessage(tab.id, {
          action: 'applySettings',
          settings
        });
      } catch (e) {
        // Tab may not have content script
      }
    }
  }
}

// ─── Utility ─────────────────────────────────────────────────
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ─── Startup ─────────────────────────────────────────────────
(async () => {
  await loadSettings();
  applyNetworkRules();
  setupAlarms();
  initTabTracking();
  console.log('[Pi Optimizer] Background worker started — Raspberry Pi 3 Mode Active');
})();
